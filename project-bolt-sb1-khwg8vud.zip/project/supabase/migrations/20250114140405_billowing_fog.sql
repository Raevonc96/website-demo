/*
  # Initial Schema Setup for Content Scheduler

  1. New Tables
    - `users`
      - `id` (uuid, primary key) - User's unique identifier
      - `email` (text) - User's email address
      - `role` (text) - User's role (admin, editor, viewer)
      - `created_at` (timestamptz) - Account creation timestamp
      - `last_active` (timestamptz) - Last activity timestamp
    
    - `posts`
      - `id` (uuid, primary key) - Post's unique identifier
      - `content` (text) - Post content
      - `platforms` (text[]) - Target social media platforms
      - `scheduled_time` (timestamptz) - Scheduled publishing time
      - `status` (text) - Post status (draft, scheduled, published)
      - `author_id` (uuid) - Reference to users table
      - `created_at` (timestamptz) - Post creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp
    
    - `media`
      - `id` (uuid, primary key) - Media item's unique identifier
      - `url` (text) - Media file URL
      - `type` (text) - Media type (image, video)
      - `title` (text) - Media title
      - `post_id` (uuid) - Reference to posts table
      - `created_at` (timestamptz) - Upload timestamp
    
    - `platform_connections`
      - `id` (uuid, primary key) - Connection's unique identifier
      - `user_id` (uuid) - Reference to users table
      - `platform` (text) - Platform name
      - `access_token` (text) - Encrypted access token
      - `refresh_token` (text) - Encrypted refresh token
      - `token_expiry` (timestamptz) - Token expiration timestamp
      - `last_sync` (timestamptz) - Last synchronization timestamp
    
    - `team_members`
      - `id` (uuid, primary key) - Team member's unique identifier
      - `email` (text) - Team member's email
      - `role` (text) - Team member's role
      - `status` (text) - Invitation status
      - `joined_at` (timestamptz) - Join timestamp
      - `last_active` (timestamptz) - Last activity timestamp

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Secure token storage with encryption
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'editor',
  created_at timestamptz DEFAULT now(),
  last_active timestamptz,
  CONSTRAINT valid_role CHECK (role IN ('admin', 'editor', 'viewer'))
);

-- Create posts table
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL,
  platforms text[] NOT NULL,
  scheduled_time timestamptz,
  status text NOT NULL DEFAULT 'draft',
  author_id uuid REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('draft', 'scheduled', 'published'))
);

-- Create media table
CREATE TABLE IF NOT EXISTS media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  type text NOT NULL,
  title text NOT NULL,
  post_id uuid REFERENCES posts(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_type CHECK (type IN ('image', 'video'))
);

-- Create platform_connections table
CREATE TABLE IF NOT EXISTS platform_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  platform text NOT NULL,
  access_token text,
  refresh_token text,
  token_expiry timestamptz,
  last_sync timestamptz,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_platform CHECK (platform IN ('facebook', 'instagram', 'twitter', 'linkedin', 'pinterest', 'tiktok'))
);

-- Create team_members table
CREATE TABLE IF NOT EXISTS team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  role text NOT NULL DEFAULT 'editor',
  status text NOT NULL DEFAULT 'pending',
  joined_at timestamptz DEFAULT now(),
  last_active timestamptz,
  CONSTRAINT valid_role CHECK (role IN ('admin', 'editor', 'viewer')),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'active'))
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE media ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can read own posts"
  ON posts
  FOR SELECT
  TO authenticated
  USING (author_id = auth.uid());

CREATE POLICY "Users can create posts"
  ON posts
  FOR INSERT
  TO authenticated
  WITH CHECK (author_id = auth.uid());

CREATE POLICY "Users can update own posts"
  ON posts
  FOR UPDATE
  TO authenticated
  USING (author_id = auth.uid());

CREATE POLICY "Users can delete own posts"
  ON posts
  FOR DELETE
  TO authenticated
  USING (author_id = auth.uid());

CREATE POLICY "Users can read media"
  ON media
  FOR SELECT
  TO authenticated
  USING (post_id IN (SELECT id FROM posts WHERE author_id = auth.uid()));

CREATE POLICY "Users can manage media"
  ON media
  FOR ALL
  TO authenticated
  USING (post_id IN (SELECT id FROM posts WHERE author_id = auth.uid()));

CREATE POLICY "Users can read own platform connections"
  ON platform_connections
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can manage platform connections"
  ON platform_connections
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Team members can read team data"
  ON team_members
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage team members"
  ON team_members
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() 
      AND role = 'admin'
    )
  );