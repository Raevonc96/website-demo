/*
  # Add YouTube Platform Support

  1. Changes
    - Update platform_connections table to allow 'youtube' as a valid platform
    - Add YouTube-specific fields for video metadata

  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  -- Update the valid_platform constraint to include YouTube
  ALTER TABLE platform_connections 
    DROP CONSTRAINT IF EXISTS valid_platform;
    
  ALTER TABLE platform_connections 
    ADD CONSTRAINT valid_platform 
    CHECK (platform IN ('facebook', 'instagram', 'twitter', 'linkedin', 'pinterest', 'tiktok', 'youtube'));

  -- Add YouTube-specific fields if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'posts' AND column_name = 'video_metadata'
  ) THEN
    ALTER TABLE posts 
    ADD COLUMN video_metadata jsonb;
  END IF;
END $$;