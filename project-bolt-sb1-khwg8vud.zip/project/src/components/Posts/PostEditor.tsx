import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { 
  Clock, 
  Send, 
  Upload, 
  Eye,
  Save,
  Calendar,
  Image as ImageIcon,
  Video,
  X,
  Star,
  Check,
  AlertCircle,
  BarChart2,
  Loader,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Camera,
  Share2
} from 'lucide-react';
import { Post, SocialPlatform } from '../../types';
import { getOptimalEngagementTimes } from '../../services/engagementTimes';
import { publishToSocialPlatforms, schedulePost } from '../../services/socialPosts';
import { useStore } from '../../store/useStore';

interface PostEditorProps {
  onSave: (post: Post) => void;
}

const platformIcons: Record<SocialPlatform, React.ElementType> = {
  facebook: Facebook,
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  pinterest: Camera,
  tiktok: Share2
};

const platformColors: Record<SocialPlatform, string> = {
  facebook: 'bg-[#1877F2]',
  instagram: 'bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737]',
  twitter: 'bg-[#1DA1F2]',
  linkedin: 'bg-[#0A66C2]',
  pinterest: 'bg-[#BD081C]',
  tiktok: 'bg-black'
};

export const PostEditor: React.FC<PostEditorProps> = ({ onSave }) => {
  const { connectedPlatforms } = useStore();
  const [content, setContent] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<SocialPlatform[]>([]);
  const [scheduledTime, setScheduledTime] = useState('');
  const [media, setMedia] = useState<File[]>([]);
  const [expandedPlatform, setExpandedPlatform] = useState<SocialPlatform | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [contentScore, setContentScore] = useState<number | null>(null);
  const [isPosting, setIsPosting] = useState(false);
  const [postResults, setPostResults] = useState<Record<SocialPlatform, boolean>>({});

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'image/*': [],
      'video/*': []
    },
    onDrop: (acceptedFiles) => {
      setMedia([...media, ...acceptedFiles]);
    }
  });

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newContent = e.target.value;
    setContent(newContent);
    analyzeContent({ content: newContent, media });
  };

  const handleSchedulePost = async () => {
    if (!content || selectedPlatforms.length === 0 || !scheduledTime) {
      return;
    }

    setIsPosting(true);
    try {
      const post: Post = {
        id: Math.random().toString(36).substring(7),
        content,
        platform: selectedPlatforms,
        scheduledTime,
        media: media.map(file => ({
          id: Math.random().toString(36).substring(7),
          url: URL.createObjectURL(file),
          type: file.type.startsWith('image/') ? 'image' : 'video',
          title: file.name
        })),
        hashtags: [],
        status: 'scheduled',
        authorId: 'current-user',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const results = await schedulePost(post);
      const resultMap = results.reduce((acc, result) => ({
        ...acc,
        [result.platform]: result.success
      }), {});

      setPostResults(resultMap);
      onSave(post);
    } catch (error) {
      console.error('Error scheduling post:', error);
    } finally {
      setIsPosting(false);
    }
  };

  const handlePublishNow = async () => {
    if (!content || selectedPlatforms.length === 0) {
      return;
    }

    setIsPosting(true);
    try {
      const post: Post = {
        id: Math.random().toString(36).substring(7),
        content,
        platform: selectedPlatforms,
        scheduledTime: new Date().toISOString(),
        media: media.map(file => ({
          id: Math.random().toString(36).substring(7),
          url: URL.createObjectURL(file),
          type: file.type.startsWith('image/') ? 'image' : 'video',
          title: file.name
        })),
        hashtags: [],
        status: 'published',
        authorId: 'current-user',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const results = await publishToSocialPlatforms(post);
      const resultMap = results.reduce((acc, result) => ({
        ...acc,
        [result.platform]: result.success
      }), {});

      setPostResults(resultMap);
      onSave(post);
    } catch (error) {
      console.error('Error publishing post:', error);
    } finally {
      setIsPosting(false);
    }
  };

  // Rest of the component implementation remains the same...
  // (Keep all the existing helper functions and JSX)

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Create New Post</h2>
        
        {/* Content Editor */}
        <div className="space-y-4">
          <textarea
            value={content}
            onChange={handleContentChange}
            placeholder="What would you like to share?"
            className="w-full h-32 p-4 border rounded-lg resize-none focus:ring-2 focus:ring-blue-500"
          />
          
          {/* Media Upload */}
          <div
            {...getRootProps()}
            className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:border-blue-500"
          >
            <input {...getInputProps()} />
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-2 text-sm text-gray-600">
              Drag and drop media files here, or click to select files
            </p>
          </div>

          {/* Media Preview */}
          {media.length > 0 && (
            <div className="grid grid-cols-2 gap-4">
              {media.map((file, index) => (
                <div key={index} className="relative">
                  {file.type.startsWith('image/') ? (
                    <img
                      src={URL.createObjectURL(file)}
                      alt={`Preview ${index + 1}`}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  ) : (
                    <video
                      src={URL.createObjectURL(file)}
                      className="w-full h-48 object-cover rounded-lg"
                      controls
                    />
                  )}
                  <button
                    onClick={() => setMedia(media.filter((_, i) => i !== index))}
                    className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-md hover:bg-red-50"
                  >
                    <X className="h-4 w-4 text-red-500" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Platform Selection */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              Select Platforms
            </label>
            <div className="flex flex-wrap gap-2">
              {connectedPlatforms.filter(p => p.connected).map((platform) => {
                const PlatformIcon = platformIcons[platform.platform];
                return (
                  <button
                    key={platform.platform}
                    onClick={() => {
                      if (selectedPlatforms.includes(platform.platform)) {
                        setSelectedPlatforms(selectedPlatforms.filter(p => p !== platform.platform));
                      } else {
                        setSelectedPlatforms([...selectedPlatforms, platform.platform]);
                      }
                    }}
                    className={`flex items-center px-4 py-2 rounded-full text-sm font-medium space-x-2 ${
                      selectedPlatforms.includes(platform.platform)
                        ? `${platformColors[platform.platform]} text-white`
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <PlatformIcon className="h-4 w-4" />
                    <span>{platform.platform}</span>
                    {postResults[platform.platform] !== undefined && (
                      postResults[platform.platform] ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <X className="h-4 w-4 text-red-500" />
                      )
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Keep the existing scheduling UI and best times to post section */}
          {/* ... */}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-4 mt-6">
            <button
              onClick={() => onSave({
                id: Math.random().toString(36).substring(7),
                content,
                platform: selectedPlatforms,
                scheduledTime: '',
                media: media.map(file => ({
                  id: Math.random().toString(36).substring(7),
                  url: URL.createObjectURL(file),
                  type: file.type.startsWith('image/') ? 'image' : 'video',
                  title: file.name
                })),
                hashtags: [],
                status: 'draft',
                authorId: 'current-user',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
              })}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
              disabled={isPosting}
            >
              Save as Draft
            </button>
            
            {scheduledTime && (
              <button
                onClick={handleSchedulePost}
                className="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 flex items-center"
                disabled={isPosting || !content || selectedPlatforms.length === 0}
              >
                {isPosting ? (
                  <>
                    <Loader className="h-4 w-4 mr-2 animate-spin" />
                    Scheduling...
                  </>
                ) : (
                  <>
                    <Calendar className="h-4 w-4 mr-2" />
                    Schedule Post
                  </>
                )}
              </button>
            )}
            
            <button
              onClick={handlePublishNow}
              className="px-4 py-2 text-white bg-green-600 rounded-lg hover:bg-green-700 flex items-center"
              disabled={isPosting || !content || selectedPlatforms.length === 0}
            >
              {isPosting ? (
                <>
                  <Loader className="h-4 w-4 mr-2 animate-spin" />
                  Posting...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Publish Now
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};