import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  Mail, 
  Shield, 
  CheckCircle2 as CheckCircle, 
  X, 
  Edit2, 
  Trash2,
  AlertCircle,
  Clock,
  Lock,
  Unlock,
  MoreVertical
} from 'lucide-react';
import { TeamMember, Role } from '../../types';
import { useStore } from '../../store/useStore';

export const TeamManagement: React.FC = () => {
  const { teamMembers, addTeamMember, updateTeamMember, removeTeamMember } = useStore();
  const [inviteEmail, setInviteEmail] = useState('');
  const [selectedRole, setSelectedRole] = useState<Role['id']>('editor');

  const handleInvite = () => {
    if (!inviteEmail) return;

    const newMember: TeamMember = {
      id: Math.random().toString(36).substring(7),
      email: inviteEmail,
      role: selectedRole,
      status: 'pending',
      joinedAt: new Date().toISOString(),
      lastActive: null
    };

    addTeamMember(newMember);
    setInviteEmail('');
    setSelectedRole('editor');
  };

  const roles: { id: Role['id']; name: string; description: string }[] = [
    {
      id: 'admin',
      name: 'Administrator',
      description: 'Full access to all features and settings'
    },
    {
      id: 'editor',
      name: 'Editor',
      description: 'Can create and publish content'
    },
    {
      id: 'viewer',
      name: 'Viewer',
      description: 'Can view content and analytics'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="border-b pb-4 mb-6">
          <h2 className="text-xl font-semibold">Team Management</h2>
          <p className="text-sm text-gray-600 mt-1">
            Manage team members and their permissions
          </p>
        </div>

        {/* Invite Form */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <h3 className="text-lg font-medium mb-4">Invite Team Member</h3>
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="Enter email address"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="w-48">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Role
              </label>
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value as Role['id'])}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                {roles.map((role) => (
                  <option key={role.id} value={role.id}>
                    {role.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={handleInvite}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <UserPlus className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Team Members List */}
        <div className="space-y-4">
          {teamMembers.map((member) => (
            <div
              key={member.id}
              className="flex items-center justify-between p-4 bg-white border rounded-lg hover:shadow-sm transition-shadow"
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Users className="h-5 w-5 text-gray-500" />
                </div>
                <div>
                  <h4 className="font-medium">{member.email}</h4>
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <span className="capitalize">{member.role}</span>
                    <span>•</span>
                    <span className="flex items-center">
                      {member.status === 'pending' ? (
                        <>
                          <Clock className="h-4 w-4 mr-1" />
                          Pending
                        </>
                      ) : (
                        <>
                          <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
                          Active
                        </>
                      )}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    const newRole = member.role === 'admin' ? 'editor' : 'admin';
                    updateTeamMember(member.id, { role: newRole });
                  }}
                  className="p-2 text-gray-600 hover:text-blue-600 rounded-lg hover:bg-gray-100"
                  title="Toggle admin privileges"
                >
                  {member.role === 'admin' ? (
                    <Lock className="h-5 w-5" />
                  ) : (
                    <Unlock className="h-5 w-5" />
                  )}
                </button>
                <button
                  onClick={() => removeTeamMember(member.id)}
                  className="p-2 text-gray-600 hover:text-red-600 rounded-lg hover:bg-gray-100"
                  title="Remove member"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          ))}

          {teamMembers.length === 0 && (
            <div className="text-center py-12">
              <Users className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No team members</h3>
              <p className="mt-1 text-sm text-gray-500">
                Get started by inviting your first team member
              </p>
            </div>
          )}
        </div>

        {/* Role Information */}
        <div className="mt-8 border-t pt-6">
          <h3 className="text-lg font-medium mb-4">Role Permissions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {roles.map((role) => (
              <div key={role.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Shield className="h-5 w-5 text-blue-600" />
                  <h4 className="font-medium">{role.name}</h4>
                </div>
                <p className="text-sm text-gray-600">{role.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};