import React, { useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { useStore } from '../../store/useStore';
import { Post } from '../../types';
import { Edit2, Trash2, X, Calendar as CalendarIcon, AlertCircle, CheckCircle, Clock, MinusCircle } from 'lucide-react';
import { format } from 'date-fns';

export const ContentCalendar: React.FC = () => {
  const { posts, updatePost, deletePost } = useStore();
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState('');

  const getStatusColor = (status: string) => {
    const colors = {
      published: { bg: '#10B981', text: 'text-green-600', icon: CheckCircle }, // Green for posted
      scheduled: { bg: '#3B82F6', text: 'text-blue-600', icon: Clock }, // Blue for pending
      error: { bg: '#EF4444', text: 'text-red-600', icon: AlertCircle }, // Red for error
      empty: { bg: '#9CA3AF', text: 'text-gray-600', icon: MinusCircle }, // Grey for nothing posted
    };
    return colors[status as keyof typeof colors] || colors.empty;
  };

  const events = posts.map((post) => ({
    id: post.id,
    title: post.content.substring(0, 30) + (post.content.length > 30 ? '...' : ''),
    start: post.scheduledTime,
    end: post.scheduledTime,
    backgroundColor: getStatusColor(post.status).bg,
    borderColor: getStatusColor(post.status).bg,
    extendedProps: {
      post: post,
      status: post.status,
    },
  }));

  const handleEventClick = (info: any) => {
    const post = info.event.extendedProps.post;
    setSelectedPost(post);
    setEditedContent(post.content);
    setIsEditing(false);
  };

  const handleEventDrop = (info: any) => {
    const post = info.event.extendedProps.post;
    const newPost = {
      ...post,
      scheduledTime: info.event.start.toISOString(),
    };
    updatePost(newPost);
  };

  const handleSaveEdit = () => {
    if (selectedPost) {
      const updatedPost = {
        ...selectedPost,
        content: editedContent,
      };
      updatePost(updatedPost);
      setIsEditing(false);
    }
  };

  const handleDelete = () => {
    if (selectedPost) {
      deletePost(selectedPost.id);
      setSelectedPost(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Status Legend */}
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <div className="flex items-center space-x-6">
          <h3 className="text-sm font-medium text-gray-700">Post Status:</h3>
          <div className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="text-sm">Posted</span>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-blue-600" />
            <span className="text-sm">Pending</span>
          </div>
          <div className="flex items-center space-x-2">
            <MinusCircle className="h-5 w-5 text-gray-600" />
            <span className="text-sm">Empty</span>
          </div>
          <div className="flex items-center space-x-2">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <span className="text-sm">Error</span>
          </div>
        </div>
      </div>

      {/* Calendar */}
      <div className="bg-white p-4 rounded-lg shadow-lg">
        <FullCalendar
          plugins={[dayGridPlugin, interactionPlugin]}
          initialView="dayGridMonth"
          events={events}
          editable={true}
          droppable={true}
          eventClick={handleEventClick}
          eventDrop={handleEventDrop}
          height="auto"
          headerToolbar={{
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,dayGridWeek,dayGridDay',
          }}
        />
      </div>

      {/* Post Details Modal */}
      {selectedPost && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Post Details</h3>
                <button
                  onClick={() => setSelectedPost(null)}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-4">
                {isEditing ? (
                  <textarea
                    value={editedContent}
                    onChange={(e) => setEditedContent(e.target.value)}
                    className="w-full h-32 p-2 border rounded-lg resize-none"
                  />
                ) : (
                  <p className="text-gray-700">{selectedPost.content}</p>
                )}

                <div className="flex items-center space-x-2">
                  <CalendarIcon className="h-5 w-5 text-gray-500" />
                  <span className="text-sm text-gray-600">
                    {format(new Date(selectedPost.scheduledTime), 'PPpp')}
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  {getStatusColor(selectedPost.status).icon({
                    className: `h-5 w-5 ${getStatusColor(selectedPost.status).text}`,
                  })}
                  <span className="text-sm capitalize">{selectedPost.status}</span>
                </div>

                <div className="flex items-center space-x-2">
                  {selectedPost.platform.map((platform) => (
                    <span
                      key={platform}
                      className="px-2 py-1 text-sm bg-gray-100 rounded-full"
                    >
                      {platform}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-2 mt-6">
                <button
                  onClick={handleDelete}
                  className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg flex items-center"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </button>
                {isEditing ? (
                  <button
                    onClick={handleSaveEdit}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Save Changes
                  </button>
                ) : (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center"
                  >
                    <Edit2 className="h-4 w-4 mr-2" />
                    Edit
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};