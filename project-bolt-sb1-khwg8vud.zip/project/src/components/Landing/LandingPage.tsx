import React from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  Clock,
  Share2,
  BarChart2,
  MessageCircle,
  Upload,
  Zap,
  CheckCircle,
  ArrowRight,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Camera,
  Layout
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const features = [
    {
      icon: Calendar,
      title: 'Visual Calendar',
      description: 'Plan and visualize your content schedule with an intuitive drag-and-drop calendar interface.'
    },
    {
      icon: Share2,
      title: 'Multi-Platform Publishing',
      description: 'Post to multiple social media platforms simultaneously with a single click.'
    },
    {
      icon: Clock,
      title: 'Smart Scheduling',
      description: 'Get AI-powered recommendations for the best times to post based on your audience.'
    },
    {
      icon: BarChart2,
      title: 'Analytics Dashboard',
      description: 'Track performance metrics and engagement across all your social media channels.'
    },
    {
      icon: MessageCircle,
      title: 'Unified Inbox',
      description: 'Manage all your social media interactions and comments from one central location.'
    },
    {
      icon: Upload,
      title: 'Media Management',
      description: 'Organize and store your images and videos in a searchable media library.'
    }
  ];

  const steps = [
    {
      number: 1,
      title: 'Connect Your Accounts',
      description: 'Start by connecting your social media accounts securely using OAuth authentication.',
      link: '/settings',
      linkText: 'Connect Accounts'
    },
    {
      number: 2,
      title: 'Create Your First Post',
      description: 'Use our intuitive editor to craft the perfect post with media and hashtags.',
      link: '/create',
      linkText: 'Create Post'
    },
    {
      number: 3,
      title: 'Schedule Content',
      description: 'Choose optimal posting times and schedule your content across platforms.',
      link: '/calendar',
      linkText: 'View Calendar'
    },
    {
      number: 4,
      title: 'Monitor Performance',
      description: 'Track engagement and analyze your content performance with detailed analytics.',
      link: '/analytics',
      linkText: 'View Analytics'
    }
  ];

  const platforms = [
    { icon: Facebook, name: 'Facebook', color: 'bg-[#1877F2]' },
    { icon: Instagram, name: 'Instagram', color: 'bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737]' },
    { icon: Twitter, name: 'Twitter', color: 'bg-[#1DA1F2]' },
    { icon: Linkedin, name: 'LinkedIn', color: 'bg-[#0A66C2]' },
    { icon: Camera, name: 'Pinterest', color: 'bg-[#BD081C]' },
    { icon: Layout, name: 'TikTok', color: 'bg-black' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
            Streamline Your Social Media
            <span className="block text-blue-600">Content Management</span>
          </h1>
          <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
            Schedule, publish, and analyze your social media content across multiple platforms from one central dashboard.
          </p>
          <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
            <div className="rounded-md shadow">
              <Link
                to="/create"
                className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10"
              >
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Supported Platforms */}
      <div className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Supported Platforms</h2>
            <p className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Connect All Your Social Media
            </p>
          </div>
          <div className="mt-10">
            <div className="grid grid-cols-2 gap-8 md:grid-cols-6">
              {platforms.map((platform) => (
                <div key={platform.name} className="col-span-1 flex justify-center">
                  <div className={`w-16 h-16 ${platform.color} rounded-lg flex items-center justify-center text-white`}>
                    <platform.icon className="h-8 w-8" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Features</h2>
            <p className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Everything You Need to Succeed
            </p>
          </div>
          <div className="mt-10">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {features.map((feature) => (
                <div
                  key={feature.title}
                  className="relative group bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-blue-500 rounded-lg shadow-sm hover:shadow-md transition-shadow"
                >
                  <div>
                    <span className="rounded-lg inline-flex p-3 bg-blue-50 text-blue-700 ring-4 ring-white">
                      <feature.icon className="h-6 w-6" aria-hidden="true" />
                    </span>
                  </div>
                  <div className="mt-4">
                    <h3 className="text-lg font-medium">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-sm text-gray-500">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Getting Started Steps */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base text-blue-600 font-semibold tracking-wide uppercase">Getting Started</h2>
            <p className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Four Simple Steps to Get Started
            </p>
          </div>
          <div className="mt-10">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
              {steps.map((step) => (
                <div key={step.title} className="relative">
                  <div className="absolute left-0 top-0 -ml-4 mt-2 hidden lg:block">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white text-lg font-bold">
                      {step.number}
                    </span>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <h3 className="lg:ml-2 text-lg font-medium text-gray-900 mb-2">
                      {step.title}
                    </h3>
                    <p className="lg:ml-2 text-base text-gray-500 mb-4">
                      {step.description}
                    </p>
                    <Link
                      to={step.link}
                      className="lg:ml-2 inline-flex items-center text-blue-600 hover:text-blue-700"
                    >
                      {step.linkText}
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-blue-700">
        <div className="max-w-2xl mx-auto text-center py-16 px-4 sm:py-20 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            <span className="block">Ready to get started?</span>
            <span className="block text-blue-200">Start managing your social media today.</span>
          </h2>
          <p className="mt-4 text-lg leading-6 text-blue-200">
            Join thousands of content creators and social media managers who trust our platform.
          </p>
          <Link
            to="/settings"
            className="mt-8 w-full inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-white hover:bg-blue-50 sm:w-auto"
          >
            Connect Your First Account
            <CheckCircle className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </div>
    </div>
  );
};