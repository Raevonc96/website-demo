import React from 'react';
import { useStore } from '../../store/useStore';
import { Facebook, Instagram, Twitter, Linkedin, Camera, Share2, Youtube, AlertCircle, CheckCircle2, XCircle, RefreshCw } from 'lucide-react';
import type { SocialPlatform } from '../../types';
import { initiateAuth } from '../../services/auth/socialAuth';

interface PlatformConfig {
  name: string;
  icon: React.ElementType;
  color: string;
}

const platformConfigs: Record<SocialPlatform, PlatformConfig> = {
  facebook: {
    name: 'Facebook',
    icon: Facebook,
    color: 'bg-[#1877F2]'
  },
  instagram: {
    name: 'Instagram',
    icon: Instagram,
    color: 'bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737]'
  },
  twitter: {
    name: 'Twitter',
    icon: Twitter,
    color: 'bg-[#1DA1F2]'
  },
  linkedin: {
    name: 'LinkedIn',
    icon: Linkedin,
    color: 'bg-[#0A66C2]'
  },
  pinterest: {
    name: 'Pinterest',
    icon: Camera,
    color: 'bg-[#BD081C]'
  },
  tiktok: {
    name: 'TikTok',
    icon: Share2,
    color: 'bg-black'
  },
  youtube: {
    name: 'YouTube',
    icon: Youtube,
    color: 'bg-[#FF0000]'
  }
};

export const SocialConnections: React.FC = () => {
  const { connectedPlatforms, setConnectedPlatforms } = useStore();

  const handleConnect = async (platform: SocialPlatform) => {
    try {
      initiateAuth(platform);

      const handleMessage = (event: MessageEvent) => {
        if (event.origin !== window.location.origin) return;
        if (event.data?.type === 'oauth_callback' && event.data?.platform === platform) {
          const updatedPlatforms = connectedPlatforms.map(p => 
            p.platform === platform 
              ? { ...p, connected: true, lastSync: new Date().toISOString() }
              : p
          );
          setConnectedPlatforms(updatedPlatforms);
          window.removeEventListener('message', handleMessage);
        }
      };

      window.addEventListener('message', handleMessage);
    } catch (error) {
      console.error(`Error connecting to ${platform}:`, error);
    }
  };

  const handleDisconnect = async (platform: SocialPlatform) => {
    const updatedPlatforms = connectedPlatforms.map(p => 
      p.platform === platform 
        ? { ...p, connected: false, lastSync: null }
        : p
    );
    setConnectedPlatforms(updatedPlatforms);
  };

  const handleRefresh = async (platform: SocialPlatform) => {
    const updatedPlatforms = connectedPlatforms.map(p => 
      p.platform === platform 
        ? { ...p, lastSync: new Date().toISOString() }
        : p
    );
    setConnectedPlatforms(updatedPlatforms);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="border-b pb-4 mb-6">
          <h2 className="text-xl font-semibold">Connected Accounts</h2>
          <p className="text-sm text-gray-600 mt-1">
            Connect your social media accounts to schedule and publish content
          </p>
        </div>

        <div className="space-y-4">
          {connectedPlatforms.map((platform) => {
            const config = platformConfigs[platform.platform];
            const Icon = config.icon;

            return (
              <div
                key={platform.platform}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded-lg text-white ${config.color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-medium">{config.name}</h3>
                    <p className="text-sm text-gray-500">
                      {platform.connected
                        ? `Last synced: ${new Date(platform.lastSync!).toLocaleDateString()}`
                        : 'Not connected'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  {platform.connected ? (
                    <>
                      <button
                        onClick={() => handleRefresh(platform.platform)}
                        className="p-2 text-gray-600 hover:text-gray-900 rounded-full hover:bg-gray-200"
                        title="Refresh connection"
                      >
                        <RefreshCw className="h-5 w-5" />
                      </button>
                      <button
                        onClick={() => handleDisconnect(platform.platform)}
                        className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Disconnect
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => handleConnect(platform.platform)}
                      className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                    >
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Connect
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-4 border border-blue-100 bg-blue-50 rounded-lg">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5 mr-3" />
            <div>
              <h4 className="text-sm font-medium text-blue-800">Secure Authentication</h4>
              <p className="mt-1 text-sm text-blue-600">
                We use official OAuth 2.0 authentication to ensure your accounts are securely connected.
                Your credentials are never stored on our servers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};