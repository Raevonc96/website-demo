import React, { useState, useRef } from 'react';
import { Upload, Play, Pause, Volume2, VolumeX, Film, Sticker, Save, Edit2, ChevronDown, ChevronUp, Type, Bold, Italic, AlignLeft, AlignCenter, AlignRight, Plus, Trash2, Move } from 'lucide-react';
import { useDropzone } from 'react-dropzone';

interface VideoFilter {
  name: string;
  class: string;
}

interface DropdownMenu {
  id: string;
  title: string;
  icon: React.ReactNode;
}

interface TextLayer {
  id: string;
  text: string;
  font: string;
  size: number;
  weight: string;
  color: string;
  italic: boolean;
  alignment: 'left' | 'center' | 'right';
  position: { x: number; y: number };
}

const filters: VideoFilter[] = [
  { name: 'None', class: '' },
  { name: 'Grayscale', class: 'grayscale' },
  { name: 'Sepia', class: 'sepia' },
  { name: 'Blur', class: 'blur' },
  { name: 'Brightness', class: 'brightness-125' },
  { name: 'Contrast', class: 'contrast-125' },
  { name: 'Saturate', class: 'saturate-150' },
  { name: 'Hue Rotate', class: 'hue-rotate-90' },
  { name: 'Invert', class: 'invert' },
  { name: 'Vintage', class: 'sepia brightness-75' },
  { name: 'Cool', class: 'hue-rotate-180 brightness-110' },
  { name: 'Warm', class: 'sepia brightness-125 contrast-75' }
];

const fontFamilies = [
  { name: 'Roboto', value: '"Roboto", sans-serif' },
  { name: 'Open Sans', value: '"Open Sans", sans-serif' },
  { name: 'Lato', value: '"Lato", sans-serif' },
  { name: 'Montserrat', value: '"Montserrat", sans-serif' },
  { name: 'Playfair Display', value: '"Playfair Display", serif' },
  { name: 'Source Code Pro', value: '"Source Code Pro", monospace' },
  { name: 'Dancing Script', value: '"Dancing Script", cursive' },
];

const fontWeights = [
  { name: 'Light', value: '300' },
  { name: 'Regular', value: '400' },
  { name: 'Medium', value: '500' },
  { name: 'Semi Bold', value: '600' },
  { name: 'Bold', value: '700' },
  { name: 'Extra Bold', value: '800' },
];

const fontSizes = Array.from({ length: 20 }, (_, i) => (i + 1) * 4);

export const VideoEditor: React.FC = () => {
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<VideoFilter>(filters[0]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [textLayers, setTextLayers] = useState<TextLayer[]>([]);
  const [selectedLayer, setSelectedLayer] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const menus: DropdownMenu[] = [
    { id: 'filters', title: 'Filters', icon: <Film className="h-5 w-5" /> },
    { id: 'text', title: 'Text', icon: <Type className="h-5 w-5" /> },
    { id: 'stickers', title: 'Stickers', icon: <Sticker className="h-5 w-5" /> },
  ];

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'video/*': []
    },
    maxFiles: 1,
    onDrop: (acceptedFiles) => {
      const file = acceptedFiles[0];
      setSelectedVideo(URL.createObjectURL(file));
    }
  });

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleSaveAsDraft = () => {
    console.log('Saving as draft:', {
      title,
      description,
      filter: selectedFilter.name,
      video: selectedVideo,
      textLayers
    });
  };

  const toggleMenu = (menuId: string) => {
    setOpenMenu(openMenu === menuId ? null : menuId);
  };

  const addTextLayer = () => {
    const newLayer: TextLayer = {
      id: Math.random().toString(36).substring(7),
      text: 'New Text',
      font: fontFamilies[0].value,
      size: 24,
      weight: '400',
      color: '#FFFFFF',
      italic: false,
      alignment: 'center',
      position: { x: 50, y: 50 },
    };
    setTextLayers([...textLayers, newLayer]);
    setSelectedLayer(newLayer.id);
  };

  const updateTextLayer = (id: string, updates: Partial<TextLayer>) => {
    setTextLayers(layers =>
      layers.map(layer =>
        layer.id === id ? { ...layer, ...updates } : layer
      )
    );
  };

  const deleteTextLayer = (id: string) => {
    setTextLayers(layers => layers.filter(layer => layer.id !== id));
    if (selectedLayer === id) {
      setSelectedLayer(null);
    }
  };

  return (
    <div className="h-[calc(100vh-4rem)] bg-white rounded-lg shadow-lg overflow-hidden flex flex-col">
      {/* Header */}
      <div className="border-b p-4">
        <h2 className="text-lg font-semibold">Video Editor</h2>
      </div>

      <div className="flex-1 flex">
        {/* Main Editing Area */}
        <div className="flex-1 p-6 flex flex-col">
          {selectedVideo ? (
            <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
              <video
                ref={videoRef}
                src={selectedVideo}
                className={`w-full h-full ${selectedFilter.class}`}
                onEnded={() => setIsPlaying(false)}
              />
              
              {/* Text Layers */}
              <div className="absolute inset-0">
                {textLayers.map(layer => (
                  <div
                    key={layer.id}
                    className={`absolute cursor-move ${
                      selectedLayer === layer.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    style={{
                      left: `${layer.position.x}%`,
                      top: `${layer.position.y}%`,
                      transform: 'translate(-50%, -50%)',
                      fontFamily: layer.font,
                      fontSize: `${layer.size}px`,
                      fontWeight: layer.weight,
                      fontStyle: layer.italic ? 'italic' : 'normal',
                      color: layer.color,
                      textAlign: layer.alignment,
                    }}
                    onClick={() => setSelectedLayer(layer.id)}
                  >
                    {layer.text}
                  </div>
                ))}
              </div>
              
              {/* Video Controls */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/50 to-transparent p-4">
                <div className="flex items-center justify-between text-white">
                  <div className="flex items-center space-x-4">
                    <button
                      onClick={handlePlayPause}
                      className="p-2 hover:bg-white/20 rounded-full transition-colors"
                    >
                      {isPlaying ? (
                        <Pause className="h-6 w-6" />
                      ) : (
                        <Play className="h-6 w-6" />
                      )}
                    </button>
                    <button
                      onClick={handleMute}
                      className="p-2 hover:bg-white/20 rounded-full transition-colors"
                    >
                      {isMuted ? (
                        <VolumeX className="h-6 w-6" />
                      ) : (
                        <Volume2 className="h-6 w-6" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div
              {...getRootProps()}
              className={`aspect-video border-2 border-dashed rounded-lg flex items-center justify-center cursor-pointer
                ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-500'}`}
            >
              <input {...getInputProps()} />
              <div className="text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-600">
                  Drag and drop a video file here, or click to select
                </p>
              </div>
            </div>
          )}

          {/* Video Details */}
          {selectedVideo && (
            <div className="mt-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Enter video title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Enter video description"
                />
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Tools */}
        {selectedVideo && (
          <div className="w-80 border-l p-4 space-y-2 overflow-y-auto">
            {menus.map((menu) => (
              <div key={menu.id} className="border rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleMenu(menu.id)}
                  className="w-full px-4 py-3 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center space-x-2">
                    {menu.icon}
                    <span className="font-medium">{menu.title}</span>
                  </div>
                  {openMenu === menu.id ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </button>

                {openMenu === menu.id && (
                  <div className="p-4 bg-white">
                    {menu.id === 'filters' && (
                      <div className="grid grid-cols-2 gap-2">
                        {filters.map((filter) => (
                          <button
                            key={filter.name}
                            onClick={() => setSelectedFilter(filter)}
                            className={`p-2 text-sm rounded-lg transition-colors ${
                              selectedFilter.name === filter.name
                                ? 'bg-blue-100 text-blue-700'
                                : 'hover:bg-gray-100'
                            }`}
                          >
                            {filter.name}
                          </button>
                        ))}
                      </div>
                    )}

                    {menu.id === 'text' && (
                      <div className="space-y-4">
                        <button
                          onClick={addTextLayer}
                          className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Text Layer
                        </button>

                        {textLayers.length > 0 && (
                          <div className="space-y-4">
                            {/* Text Layers List */}
                            <div className="space-y-2">
                              {textLayers.map(layer => (
                                <div
                                  key={layer.id}
                                  className={`p-2 rounded-lg border cursor-pointer ${
                                    selectedLayer === layer.id
                                      ? 'border-blue-500 bg-blue-50'
                                      : 'border-gray-200 hover:border-blue-300'
                                  }`}
                                  onClick={() => setSelectedLayer(layer.id)}
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm font-medium truncate">
                                      {layer.text}
                                    </span>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        deleteTextLayer(layer.id);
                                      }}
                                      className="p-1 text-gray-400 hover:text-red-500 rounded-full hover:bg-gray-100"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>

                            {/* Text Layer Editor */}
                            {selectedLayer && (
                              <div className="space-y-4 border-t pt-4">
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Text Content
                                  </label>
                                  <input
                                    type="text"
                                    value={textLayers.find(l => l.id === selectedLayer)?.text}
                                    onChange={(e) => updateTextLayer(selectedLayer, { text: e.target.value })}
                                    className="w-full px-3 py-2 border rounded-lg text-sm"
                                  />
                                </div>

                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Font Family
                                  </label>
                                  <select
                                    value={textLayers.find(l => l.id === selectedLayer)?.font}
                                    onChange={(e) => updateTextLayer(selectedLayer, { font: e.target.value })}
                                    className="w-full px-3 py-2 border rounded-lg text-sm"
                                  >
                                    {fontFamilies.map(font => (
                                      <option key={font.value} value={font.value}>
                                        {font.name}
                                      </option>
                                    ))}
                                  </select>
                                </div>

                                <div className="grid grid-cols-2 gap-2">
                                  <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">
                                      Size
                                    </label>
                                    <select
                                      value={textLayers.find(l => l.id === selectedLayer)?.size}
                                      onChange={(e) => updateTextLayer(selectedLayer, { size: Number(e.target.value) })}
                                      className="w-full px-3 py-2 border rounded-lg text-sm"
                                    >
                                      {fontSizes.map(size => (
                                        <option key={size} value={size}>
                                          {size}px
                                        </option>
                                      ))}
                                    </select>
                                  </div>

                                  <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-1">
                                      Weight
                                    </label>
                                    <select
                                      value={textLayers.find(l => l.id === selectedLayer)?.weight}
                                      onChange={(e) => updateTextLayer(selectedLayer, { weight: e.target.value })}
                                      className="w-full px-3 py-2 border rounded-lg text-sm"
                                    >
                                      {fontWeights.map(weight => (
                                        <option key={weight.value} value={weight.value}>
                                          {weight.name}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </div>

                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Color
                                  </label>
                                  <input
                                    type="color"
                                    value={textLayers.find(l => l.id === selectedLayer)?.color}
                                    onChange={(e) => updateTextLayer(selectedLayer, { color: e.target.value })}
                                    className="w-full h-10 rounded-lg cursor-pointer"
                                  />
                                </div>

                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-2">
                                    <button
                                      onClick={() => {
                                        const layer = textLayers.find(l => l.id === selectedLayer);
                                        if (layer) {
                                          updateTextLayer(selectedLayer, { italic: !layer.italic });
                                        }
                                      }}
                                      className={`p-2 rounded-lg ${
                                        textLayers.find(l => l.id === selectedLayer)?.italic
                                          ? 'bg-blue-100 text-blue-700'
                                          : 'hover:bg-gray-100'
                                      }`}
                                    >
                                      <Italic className="h-4 w-4" />
                                    </button>
                                  </div>

                                  <div className="flex items-center space-x-1">
                                    {(['left', 'center', 'right'] as const).map((align) => (
                                      <button
                                        key={align}
                                        onClick={() => updateTextLayer(selectedLayer, { alignment: align })}
                                        className={`p-2 rounded-lg ${
                                          textLayers.find(l => l.id === selectedLayer)?.alignment === align
                                            ? 'bg-blue-100 text-blue-700'
                                            : 'hover:bg-gray-100'
                                        }`}
                                      >
                                        {align === 'left' && <AlignLeft className="h-4 w-4" />}
                                        {align === 'center' && <AlignCenter className="h-4 w-4" />}
                                        {align === 'right' && <AlignRight className="h-4 w-4" />}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )}

                    {menu.id === 'stickers' && (
                      <div className="space-y-2">
                        <button className="w-full px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50">
                          Add Sticker
                        </button>
                        <div className="text-sm text-gray-500">
                          Choose from our collection of stickers
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}

            {/* Save Options */}
            <div className="pt-4 border-t mt-4">
              <button
                onClick={handleSaveAsDraft}
                className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-lg text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
              >
                <Save className="h-4 w-4 mr-2" />
                Save as Draft
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};