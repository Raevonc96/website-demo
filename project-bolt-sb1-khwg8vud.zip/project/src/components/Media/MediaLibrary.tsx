import React, { useState, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { Image, Video, Trash2, Download, Search, Filter, Grid, List, Upload, Edit2, X, Play, Pause, Loader } from 'lucide-react';
import { Media } from '../../types';
import { useStore } from '../../store/useStore';

interface UploadingFile {
  id: string;
  file: File;
  preview: string;
  progress: number;
  type: 'image' | 'video';
  title: string;
}

export const MediaLibrary: React.FC = () => {
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'image' | 'video'>('all');
  const [uploadingFiles, setUploadingFiles] = useState<UploadingFile[]>([]);
  const [editingFile, setEditingFile] = useState<string | null>(null);
  const { mediaItems, addMediaItem, removeMediaItem, updateMediaItem } = useStore();

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'image/*': [],
      'video/*': [],
    },
    onDrop: (acceptedFiles) => {
      const newFiles = acceptedFiles.map(file => ({
        id: Math.random().toString(36).substring(7),
        file,
        preview: URL.createObjectURL(file),
        progress: 0,
        type: file.type.startsWith('image/') ? 'image' : 'video',
        title: file.name,
      }));
      setUploadingFiles(prev => [...prev, ...newFiles]);
      
      // Simulate upload progress
      newFiles.forEach(file => {
        simulateUploadProgress(file.id);
      });
    },
  });

  useEffect(() => {
    return () => {
      uploadingFiles.forEach(file => {
        URL.revokeObjectURL(file.preview);
      });
    };
  }, [uploadingFiles]);

  const simulateUploadProgress = (fileId: string) => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 10;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        
        // When upload is complete, add to media library
        const completedFile = uploadingFiles.find(f => f.id === fileId);
        if (completedFile) {
          addMediaItem({
            id: completedFile.id,
            url: completedFile.preview,
            type: completedFile.type,
            title: completedFile.title,
          });
          
          // Remove from uploading files
          setUploadingFiles(prev => prev.filter(f => f.id !== fileId));
        }
      }
      setUploadingFiles(prev => 
        prev.map(file => 
          file.id === fileId ? { ...file, progress: Math.min(progress, 100) } : file
        )
      );
    }, 300);
  };

  const handleRemoveUpload = (id: string) => {
    setUploadingFiles(prev => {
      const file = prev.find(f => f.id === id);
      if (file) {
        URL.revokeObjectURL(file.preview);
      }
      return prev.filter(file => file.id !== id);
    });
    if (editingFile === id) {
      setEditingFile(null);
    }
  };

  const handleRemoveMedia = (id: string) => {
    removeMediaItem(id);
  };

  const handleUpdateTitle = (id: string, title: string) => {
    updateMediaItem(id, { title });
    setEditingFile(null);
  };

  const filteredMedia = mediaItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || item.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Media Library</h1>
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setView('grid')}
            className={`p-2 rounded-lg ${view === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            <Grid className="h-5 w-5" />
          </button>
          <button
            onClick={() => setView('list')}
            className={`p-2 rounded-lg ${view === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            <List className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search media..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value as 'all' | 'image' | 'video')}
            className="border border-gray-300 rounded-lg px-4 py-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Types</option>
            <option value="image">Images</option>
            <option value="video">Videos</option>
          </select>
        </div>
      </div>

      {/* Upload Area */}
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer
          ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-500'}`}
      >
        <input {...getInputProps()} />
        <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <p className="text-gray-600">
          {isDragActive ? 'Drop files here...' : 'Drag and drop media files here, or click to select files'}
        </p>
        <p className="text-sm text-gray-500 mt-2">Supports images and videos up to 100MB</p>
      </div>

      {/* Uploading Files */}
      {uploadingFiles.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Uploading Files</h2>
          <div className="grid grid-cols-1 gap-4">
            {uploadingFiles.map((file) => (
              <div key={file.id} className="bg-white rounded-lg shadow-sm p-4">
                <div className="flex items-start space-x-4">
                  <div className="relative w-32 h-32 flex-shrink-0 bg-gray-100 rounded-lg overflow-hidden">
                    {file.type === 'image' ? (
                      <img
                        src={file.preview}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <video
                        src={file.preview}
                        className="w-full h-full object-cover"
                      />
                    )}
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <div className="text-white text-center">
                        <Loader className="animate-spin h-8 w-8 mb-2 mx-auto" />
                        <span className="text-sm">{Math.round(file.progress)}%</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium">{file.title}</h3>
                      <button
                        onClick={() => handleRemoveUpload(file.id)}
                        className="p-1.5 text-gray-600 hover:text-red-600 rounded-lg hover:bg-gray-100"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-2">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${file.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Media Grid/List */}
      {filteredMedia.length > 0 ? (
        view === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMedia.map((item) => (
              <div key={item.id} className="group relative bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="aspect-w-16 aspect-h-9">
                  {item.type === 'image' ? (
                    <img
                      src={item.url}
                      alt={item.title}
                      className="object-cover w-full h-full"
                    />
                  ) : (
                    <video
                      src={item.url}
                      className="object-cover w-full h-full"
                    />
                  )}
                </div>
                <div className="p-4">
                  {editingFile === item.id ? (
                    <input
                      type="text"
                      value={item.title}
                      onChange={(e) => handleUpdateTitle(item.id, e.target.value)}
                      onBlur={() => setEditingFile(null)}
                      className="w-full px-2 py-1 border rounded"
                      autoFocus
                    />
                  ) : (
                    <h3 className="font-medium text-gray-900">{item.title}</h3>
                  )}
                  <p className="text-sm text-gray-500 capitalize mt-1">{item.type}</p>
                </div>
                <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-4">
                  <button className="p-2 bg-white rounded-full text-gray-700 hover:text-blue-600">
                    <Download className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => setEditingFile(item.id)}
                    className="p-2 bg-white rounded-full text-gray-700 hover:text-blue-600"
                  >
                    <Edit2 className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => handleRemoveMedia(item.id)}
                    className="p-2 bg-white rounded-full text-gray-700 hover:text-red-600"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredMedia.map((item) => (
              <div key={item.id} className="flex items-center space-x-4 bg-white p-4 rounded-lg shadow-sm">
                <div className="h-20 w-20 flex-shrink-0">
                  {item.type === 'image' ? (
                    <img
                      src={item.url}
                      alt={item.title}
                      className="h-full w-full object-cover rounded"
                    />
                  ) : (
                    <video
                      src={item.url}
                      className="h-full w-full object-cover rounded"
                    />
                  )}
                </div>
                <div className="flex-1">
                  {editingFile === item.id ? (
                    <input
                      type="text"
                      value={item.title}
                      onChange={(e) => handleUpdateTitle(item.id, e.target.value)}
                      onBlur={() => setEditingFile(null)}
                      className="w-full px-2 py-1 border rounded"
                      autoFocus
                    />
                  ) : (
                    <h3 className="font-medium text-gray-900">{item.title}</h3>
                  )}
                  <p className="text-sm text-gray-500 capitalize">{item.type}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-gray-600 hover:text-blue-600 rounded-lg hover:bg-gray-100">
                    <Download className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => setEditingFile(item.id)}
                    className="p-2 text-gray-600 hover:text-blue-600 rounded-lg hover:bg-gray-100"
                  >
                    <Edit2 className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => handleRemoveMedia(item.id)}
                    className="p-2 text-gray-600 hover:text-red-600 rounded-lg hover:bg-gray-100"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        <div className="text-center py-12">
          <Upload className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No media files</h3>
          <p className="mt-1 text-sm text-gray-500">Upload files to get started</p>
        </div>
      )}
    </div>
  );
};