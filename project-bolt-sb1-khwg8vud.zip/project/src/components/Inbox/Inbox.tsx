import React, { useState, useEffect } from 'react';
import { 
  MessageCircle, 
  Search, 
  Filter,
  Star,
  Archive,
  RefreshCw,
  AlertCircle,
  Clock,
  CheckCircle2 as CheckCircle,
  XCircle,
  Reply,
  MoreVertical,
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Camera,
  Share2
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { format } from 'date-fns';
import type { SocialPlatform } from '../../types';

interface Message {
  id: string;
  platform: SocialPlatform;
  sender: {
    name: string;
    avatar?: string;
    id: string;
  };
  content: string;
  timestamp: string;
  read: boolean;
  starred: boolean;
  type: 'comment' | 'direct' | 'mention';
  postId?: string;
  replyTo?: string;
}

const platformIcons: Record<SocialPlatform, React.ElementType> = {
  facebook: Facebook,
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  pinterest: Camera,
  tiktok: Share2
};

const platformColors: Record<SocialPlatform, string> = {
  facebook: 'bg-[#1877F2]',
  instagram: 'bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#F77737]',
  twitter: 'bg-[#1DA1F2]',
  linkedin: 'bg-[#0A66C2]',
  pinterest: 'bg-[#BD081C]',
  tiktok: 'bg-black'
};

export const Inbox: React.FC = () => {
  const { connectedPlatforms } = useStore();
  const [messages, setMessages] = useState<Message[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState<'all' | SocialPlatform>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [replyContent, setReplyContent] = useState<Record<string, string>>({});
  const [showReply, setShowReply] = useState<Record<string, boolean>>({});

  useEffect(() => {
    fetchMessages();
  }, [connectedPlatforms]);

  const fetchMessages = async () => {
    setIsLoading(true);
    try {
      // In production, this would be an API call to fetch messages from each connected platform
      // Simulating API delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      const mockMessages: Message[] = connectedPlatforms
        .filter(p => p.connected)
        .flatMap(platform => {
          return Array.from({ length: 3 }, (_, i) => ({
            id: `${platform.platform}-${i}`,
            platform: platform.platform,
            sender: {
              name: `User ${i + 1}`,
              id: `user-${i}`,
              avatar: `https://i.pravatar.cc/40?u=${platform.platform}-${i}`
            },
            content: `This is a sample ${i === 0 ? 'comment' : i === 1 ? 'direct message' : 'mention'} from ${platform.platform}`,
            timestamp: new Date(Date.now() - i * 3600000).toISOString(),
            read: false,
            starred: false,
            type: i === 0 ? 'comment' : i === 1 ? 'direct' : 'mention'
          }));
        });

      setMessages(mockMessages);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMarkAsRead = (messageId: string) => {
    setMessages(prev =>
      prev.map(msg =>
        msg.id === messageId ? { ...msg, read: true } : msg
      )
    );
  };

  const handleToggleStar = (messageId: string) => {
    setMessages(prev =>
      prev.map(msg =>
        msg.id === messageId ? { ...msg, starred: !msg.starred } : msg
      )
    );
  };

  const handleArchive = (messageId: string) => {
    setMessages(prev => prev.filter(msg => msg.id !== messageId));
  };

  const handleReply = async (messageId: string) => {
    const content = replyContent[messageId];
    if (!content) return;

    // In production, this would send the reply to the appropriate platform
    console.log(`Sending reply to message ${messageId}:`, content);
    
    // Clear reply field and hide reply box
    setReplyContent(prev => ({ ...prev, [messageId]: '' }));
    setShowReply(prev => ({ ...prev, [messageId]: false }));
  };

  const filteredMessages = messages.filter(message => {
    const matchesSearch = message.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         message.sender.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPlatform = selectedPlatform === 'all' || message.platform === selectedPlatform;
    return matchesSearch && matchesPlatform;
  });

  const connectedPlatformsList = connectedPlatforms.filter(p => p.connected);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Unified Inbox</h1>
        <button 
          onClick={fetchMessages}
          className="p-2 text-gray-600 hover:text-gray-900 rounded-full hover:bg-gray-100"
        >
          <RefreshCw className="h-5 w-5" />
        </button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search messages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        <select
          value={selectedPlatform}
          onChange={(e) => setSelectedPlatform(e.target.value as 'all' | SocialPlatform)}
          className="border border-gray-300 rounded-lg px-4 py-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="all">All Platforms</option>
          {connectedPlatformsList.map(p => (
            <option key={p.platform} value={p.platform}>
              {p.platform.charAt(0).toUpperCase() + p.platform.slice(1)}
            </option>
          ))}
        </select>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      ) : filteredMessages.length > 0 ? (
        <div className="space-y-4">
          {filteredMessages.map((message) => {
            const PlatformIcon = platformIcons[message.platform];
            
            return (
              <div
                key={message.id}
                className={`p-4 bg-white rounded-lg shadow-sm border-l-4 ${
                  message.read ? 'border-gray-200' : 'border-blue-500'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="relative">
                      <img
                        src={message.sender.avatar}
                        alt={message.sender.name}
                        className="w-10 h-10 rounded-full"
                      />
                      <div className={`absolute -bottom-1 -right-1 p-1 rounded-full text-white ${platformColors[message.platform]}`}>
                        <PlatformIcon className="h-3 w-3" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{message.sender.name}</span>
                        <span className="text-sm text-gray-500">via {message.platform}</span>
                        <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-600">
                          {message.type}
                        </span>
                      </div>
                      <p className="mt-1 text-gray-600">{message.content}</p>
                      <div className="mt-2 flex items-center space-x-4 text-sm text-gray-500">
                        <span className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {format(new Date(message.timestamp), 'MMM d, h:mm a')}
                        </span>
                        <button
                          onClick={() => setShowReply(prev => ({ ...prev, [message.id]: !prev[message.id] }))}
                          className="flex items-center text-blue-600 hover:text-blue-700"
                        >
                          <Reply className="h-4 w-4 mr-1" />
                          Reply
                        </button>
                      </div>

                      {showReply[message.id] && (
                        <div className="mt-3 space-y-2">
                          <textarea
                            value={replyContent[message.id] || ''}
                            onChange={(e) => setReplyContent(prev => ({ ...prev, [message.id]: e.target.value }))}
                            placeholder="Type your reply..."
                            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 resize-none"
                            rows={3}
                          />
                          <div className="flex justify-end space-x-2">
                            <button
                              onClick={() => setShowReply(prev => ({ ...prev, [message.id]: false }))}
                              className="px-3 py-1 text-gray-600 hover:text-gray-900"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={() => handleReply(message.id)}
                              className="px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                            >
                              Send Reply
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-start space-x-2">
                    <button
                      onClick={() => handleToggleStar(message.id)}
                      className={`p-1.5 rounded-full hover:bg-gray-100 ${
                        message.starred ? 'text-yellow-500' : 'text-gray-400 hover:text-yellow-500'
                      }`}
                    >
                      <Star className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleArchive(message.id)}
                      className="p-1.5 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
                    >
                      <Archive className="h-5 w-5" />
                    </button>
                    {!message.read && (
                      <button
                        onClick={() => handleMarkAsRead(message.id)}
                        className="p-1.5 text-blue-600 hover:text-blue-700 rounded-full hover:bg-gray-100"
                      >
                        <CheckCircle className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : connectedPlatformsList.length === 0 ? (
        <div className="text-center py-12">
          <AlertCircle className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No Connected Accounts</h3>
          <p className="mt-1 text-sm text-gray-500">
            Connect your social media accounts to start receiving messages
          </p>
        </div>
      ) : (
        <div className="text-center py-12">
          <MessageCircle className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No messages</h3>
          <p className="mt-1 text-sm text-gray-500">
            Your inbox is empty
          </p>
        </div>
      )}
    </div>
  );
};