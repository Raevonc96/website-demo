import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Calendar, 
  PlusCircle, 
  Clock, 
  Bell, 
  BarChart2, 
  MessageCircle,
  Zap,
  TrendingUp,
  Users,
  Activity,
  ChevronDown,
  ChevronUp,
  Star
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { format } from 'date-fns';
import { getOptimalEngagementTimes } from '../../services/engagementTimes';
import type { SocialPlatform } from '../../types';

export const Dashboard: React.FC = () => {
  const { posts, platformStats } = useStore();
  const [expandedPlatforms, setExpandedPlatforms] = useState<SocialPlatform[]>([]);

  // Get upcoming scheduled posts
  const upcomingPosts = posts
    .filter(post => post.status === 'scheduled')
    .sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime())
    .slice(0, 3);

  // Calculate quick stats
  const totalScheduledPosts = posts.filter(post => post.status === 'scheduled').length;
  const totalPublishedPosts = posts.filter(post => post.status === 'published').length;
  const totalDrafts = posts.filter(post => post.status === 'draft').length;

  const platforms: SocialPlatform[] = ['facebook', 'instagram', 'twitter', 'linkedin', 'pinterest', 'tiktok'];

  const getPlatformColor = (platform: SocialPlatform) => {
    const colors = {
      facebook: 'from-[#1877F2] to-[#0A66C2]',
      instagram: 'from-[#833AB4] to-[#FD1D1D]',
      twitter: 'from-[#1DA1F2] to-[#0A66C2]',
      linkedin: 'from-[#0A66C2] to-[#0077B5]',
      pinterest: 'from-[#BD081C] to-[#E60023]',
      tiktok: 'from-[#000000] to-[#25F4EE]',
    };
    return colors[platform];
  };

  const togglePlatform = (platform: SocialPlatform) => {
    setExpandedPlatforms(prev => 
      prev.includes(platform)
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link to="/create" className="flex items-center p-6 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
          <PlusCircle className="h-6 w-6 mr-3" />
          <span className="text-lg font-medium">Create New Post</span>
        </Link>
        <Link to="/calendar" className="flex items-center p-6 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
          <Calendar className="h-6 w-6 mr-3" />
          <span className="text-lg font-medium">View Calendar</span>
        </Link>
        <Link to="/analytics" className="flex items-center p-6 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
          <BarChart2 className="h-6 w-6 mr-3" />
          <span className="text-lg font-medium">View Analytics</span>
        </Link>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Scheduled Posts</p>
              <p className="text-2xl font-bold">{totalScheduledPosts}</p>
            </div>
            <Clock className="h-8 w-8 text-blue-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Published Posts</p>
              <p className="text-2xl font-bold">{totalPublishedPosts}</p>
            </div>
            <Zap className="h-8 w-8 text-green-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Draft Posts</p>
              <p className="text-2xl font-bold">{totalDrafts}</p>
            </div>
            <PlusCircle className="h-8 w-8 text-gray-500" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Engagement</p>
              <p className="text-2xl font-bold">
                {Object.values(platformStats).reduce((acc, stat) => acc + stat.engagement, 0).toFixed(1)}%
              </p>
            </div>
            <Activity className="h-8 w-8 text-purple-500" />
          </div>
        </div>
      </div>

      {/* Best Times to Post */}
      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b">
          <h2 className="text-lg font-semibold flex items-center">
            <Clock className="h-5 w-5 mr-2 text-blue-500" />
            Best Times to Post
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            Optimal posting times based on audience engagement data
          </p>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {platforms.map(platform => {
              const timeSlots = getOptimalEngagementTimes(platform);
              const isExpanded = expandedPlatforms.includes(platform);

              return (
                <div key={platform} className="border rounded-lg overflow-hidden">
                  <button
                    onClick={() => togglePlatform(platform)}
                    className={`w-full px-4 py-3 flex items-center justify-between bg-gradient-to-r ${getPlatformColor(platform)} text-white`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-lg font-medium capitalize">{platform}</span>
                      <div className="bg-white/20 px-2 py-1 rounded text-sm">
                        {timeSlots[0].score.toFixed(1)}/10
                      </div>
                    </div>
                    {isExpanded ? (
                      <ChevronUp className="h-5 w-5" />
                    ) : (
                      <ChevronDown className="h-5 w-5" />
                    )}
                  </button>
                  
                  {isExpanded && (
                    <div className="divide-y">
                      {timeSlots.map((slot, index) => (
                        <div
                          key={`${platform}-${slot.time}`}
                          className="px-4 py-3 bg-white hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              {index === 0 && (
                                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                              )}
                              <span className="font-medium">{slot.time}</span>
                              <span className="text-gray-500">{slot.description}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm bg-blue-100 text-blue-700 px-2 py-1 rounded">
                                {slot.score.toFixed(1)}/10
                              </span>
                              <span className="text-sm text-gray-500">
                                {slot.engagement}% engagement
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-start space-x-3">
              <Zap className="h-5 w-5 text-blue-500 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-blue-800">Pro Tip</h4>
                <p className="text-sm text-blue-600 mt-1">
                  These times are based on your audience's activity patterns. For best results, schedule your posts during peak engagement hours.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Rest of the dashboard content... */}
    </div>
  );
};