import React, { useEffect } from 'react';
import { BarChart, LineChart, PieChart, Activity, TrendingUp, Users, Share2, Heart, Eye, MessageCircle, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { useStore } from '../../store/useStore';
import { ConnectedPlatform, PlatformStats } from '../../types';

export const AnalyticsDashboard: React.FC = () => {
  const {
    connectedPlatforms,
    platformStats,
    isLoadingStats,
    error,
    setIsLoadingStats,
    setPlatformStats,
    setError
  } = useStore();

  useEffect(() => {
    const fetchPlatformData = async () => {
      setIsLoadingStats(true);
      setError(null);
      
      try {
        // In production, this would be an API call to fetch real data
        // Simulating API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock data fetch based on connected platforms
        const stats: Record<string, PlatformStats> = {};
        connectedPlatforms.forEach(platform => {
          if (platform.connected) {
            stats[platform.platform] = {
              followers: Math.floor(Math.random() * 50000),
              engagement: Number((Math.random() * 6 + 1).toFixed(1)),
              posts: Math.floor(Math.random() * 300),
              likes: Math.floor(Math.random() * 100000),
              shares: Math.floor(Math.random() * 5000),
              lastUpdated: new Date().toISOString()
            };
          }
        });
        
        setPlatformStats(stats);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch analytics data');
      } finally {
        setIsLoadingStats(false);
      }
    };

    if (connectedPlatforms.some(p => p.connected)) {
      fetchPlatformData();
    }
  }, [connectedPlatforms]);

  if (connectedPlatforms.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-96">
        <AlertCircle className="h-16 w-16 text-gray-400 mb-4" />
        <h2 className="text-xl font-semibold text-gray-700">No Social Media Accounts Connected</h2>
        <p className="text-gray-500 mt-2">Connect your social media accounts to view analytics</p>
      </div>
    );
  }

  if (isLoadingStats) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-96">
        <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
        <h2 className="text-xl font-semibold text-gray-700">Error Loading Analytics</h2>
        <p className="text-gray-500 mt-2">{error}</p>
      </div>
    );
  }

  const connectedStats = Object.entries(platformStats).filter(([platform]) => 
    connectedPlatforms.find(p => p.platform === platform)?.connected
  );

  const totalStats = connectedStats.reduce((acc, [_, stats]) => ({
    followers: acc.followers + stats.followers,
    engagement: acc.engagement + stats.engagement,
    posts: acc.posts + stats.posts,
    likes: acc.likes + stats.likes,
    shares: acc.shares + stats.shares
  }), { followers: 0, engagement: 0, posts: 0, likes: 0, shares: 0 });

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Followers</p>
              <p className="text-2xl font-bold">{totalStats.followers.toLocaleString()}</p>
            </div>
            <Users className="h-8 w-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Engagement</p>
              <p className="text-2xl font-bold">{(totalStats.likes + totalStats.shares).toLocaleString()}</p>
            </div>
            <Activity className="h-8 w-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Posts</p>
              <p className="text-2xl font-bold">{totalStats.posts.toLocaleString()}</p>
            </div>
            <BarChart className="h-8 w-8 text-indigo-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg. Engagement Rate</p>
              <p className="text-2xl font-bold">
                {(totalStats.engagement / connectedStats.length).toFixed(1)}%
              </p>
            </div>
            <PieChart className="h-8 w-8 text-orange-500" />
          </div>
        </div>
      </div>

      {/* Platform Performance */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold mb-4">Platform Performance</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {connectedStats.map(([platform, stats]) => (
            <div key={platform} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-md font-medium capitalize">{platform}</h3>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{stats.followers.toLocaleString()}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Engagement Rate</span>
                  <span className="text-sm font-medium">{stats.engagement}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Total Posts</span>
                  <span className="text-sm font-medium">{stats.posts}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Total Likes</span>
                  <span className="text-sm font-medium">{stats.likes.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Total Shares</span>
                  <span className="text-sm font-medium">{stats.shares.toLocaleString()}</span>
                </div>
                <div className="text-xs text-gray-500 mt-2">
                  Last updated: {format(new Date(stats.lastUpdated), 'MMM d, yyyy HH:mm')}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};