import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import { Calendar, Layout, Home, Settings, PlusCircle, BarChart3, MessageCircle, Library, Users, Menu, X, Video } from 'lucide-react';
import { ContentCalendar } from './components/Calendar/ContentCalendar';
import { PostEditor } from './components/Posts/PostEditor';
import { AnalyticsDashboard } from './components/Analytics/AnalyticsDashboard';
import { Dashboard } from './components/Dashboard/Dashboard';
import { SocialConnections } from './components/Settings/SocialConnections';
import { MediaLibrary } from './components/Media/MediaLibrary';
import { Inbox } from './components/Inbox/Inbox';
import { LandingPage } from './components/Landing/LandingPage';
import { VideoEditor } from './components/VideoEditor/VideoEditor';
import { TeamManagement } from './components/Team/TeamManagement';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const navigation = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Dashboard', href: '/dashboard', icon: Layout },
    { name: 'Calendar', href: '/calendar', icon: Calendar },
    { name: 'Create Post', href: '/create', icon: PlusCircle },
    { name: 'Video Editor', href: '/video-editor', icon: Video },
    { name: 'Analytics', href: '/analytics', icon: BarChart3 },
    { name: 'Inbox', href: '/inbox', icon: MessageCircle },
    { name: 'Media Library', href: '/media', icon: Library },
    { name: 'Team', href: '/team', icon: Users },
    { name: 'Settings', href: '/settings', icon: Settings },
  ];

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <div className="flex h-screen">
          {/* Toggle Button */}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="fixed top-4 left-4 z-50 p-2 rounded-lg bg-white shadow-lg text-gray-600 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 lg:hidden"
          >
            {isSidebarOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>

          {/* Sidebar */}
          <div
            className={`fixed inset-y-0 left-0 transform ${
              isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
            } lg:relative lg:translate-x-0 transition-transform duration-300 ease-in-out z-30`}
          >
            <div className="flex flex-col w-64 h-full">
              <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto bg-white/80 backdrop-blur-sm border-r">
                <div className="flex items-center flex-shrink-0 px-4">
                  <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Content Scheduler</h1>
                </div>
                <div className="mt-5 flex-grow flex flex-col">
                  <nav className="flex-1 px-2 space-y-1">
                    {navigation.map((item) => (
                      <NavLink
                        key={item.name}
                        to={item.href}
                        className={({ isActive }) => `
                          group flex items-center px-2 py-2 text-sm font-medium rounded-md
                          transition-colors duration-150 ease-in-out
                          ${isActive 
                            ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white' 
                            : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}
                        `}
                        onClick={() => setIsSidebarOpen(false)}
                      >
                        <item.icon className={`mr-3 h-5 w-5 transition-colors duration-150 ease-in-out`} />
                        {item.name}
                      </NavLink>
                    ))}
                  </nav>
                </div>
              </div>
            </div>
          </div>

          {/* Overlay */}
          {isSidebarOpen && (
            <div
              className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
              onClick={() => setIsSidebarOpen(false)}
            />
          )}

          {/* Main content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <main className="flex-1 relative overflow-y-auto focus:outline-none">
              <div className="py-6">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
                  <Routes>
                    <Route path="/" element={<LandingPage />} />
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/calendar" element={<ContentCalendar />} />
                    <Route path="/create" element={<PostEditor onSave={console.log} />} />
                    <Route path="/video-editor" element={<VideoEditor />} />
                    <Route path="/analytics" element={<AnalyticsDashboard />} />
                    <Route path="/settings" element={<SocialConnections />} />
                    <Route path="/media" element={<MediaLibrary />} />
                    <Route path="/inbox" element={<Inbox />} />
                    <Route path="/team" element={<TeamManagement />} />
                  </Routes>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;