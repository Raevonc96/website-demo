import { create } from 'zustand';
import { Post, User, ConnectedPlatform, PlatformStats, Media, TeamMember } from '../types';

interface Store {
  posts: Post[];
  currentUser: User | null;
  connectedPlatforms: ConnectedPlatform[];
  platformStats: Record<string, PlatformStats>;
  mediaItems: Media[];
  teamMembers: TeamMember[];
  isLoadingStats: boolean;
  error: string | null;
  setPosts: (posts: Post[]) => void;
  addPost: (post: Post) => void;
  updatePost: (post: Post) => void;
  deletePost: (postId: string) => void;
  setCurrentUser: (user: User | null) => void;
  setConnectedPlatforms: (platforms: ConnectedPlatform[]) => void;
  setPlatformStats: (stats: Record<string, PlatformStats>) => void;
  setIsLoadingStats: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
  addMediaItem: (media: Media) => void;
  removeMediaItem: (id: string) => void;
  updateMediaItem: (id: string, updates: Partial<Media>) => void;
  addTeamMember: (member: TeamMember) => void;
  updateTeamMember: (id: string, updates: Partial<TeamMember>) => void;
  removeTeamMember: (id: string) => void;
}

const initialPlatforms: ConnectedPlatform[] = [
  { platform: 'facebook', connected: false, lastSync: null },
  { platform: 'instagram', connected: false, lastSync: null },
  { platform: 'twitter', connected: false, lastSync: null },
  { platform: 'linkedin', connected: false, lastSync: null },
  { platform: 'pinterest', connected: false, lastSync: null },
  { platform: 'tiktok', connected: false, lastSync: null },
  { platform: 'youtube', connected: false, lastSync: null },
];

export const useStore = create<Store>((set) => ({
  posts: [],
  currentUser: null,
  connectedPlatforms: initialPlatforms,
  platformStats: {},
  mediaItems: [],
  teamMembers: [],
  isLoadingStats: false,
  error: null,
  setPosts: (posts) => set({ posts }),
  addPost: (post) => set((state) => ({ posts: [...state.posts, post] })),
  updatePost: (post) => set((state) => ({
    posts: state.posts.map((p) => (p.id === post.id ? post : p)),
  })),
  deletePost: (postId) => set((state) => ({
    posts: state.posts.filter((p) => p.id !== postId),
  })),
  setCurrentUser: (user) => set({ currentUser: user }),
  setConnectedPlatforms: (platforms) => set({ connectedPlatforms: platforms }),
  setPlatformStats: (stats) => set({ platformStats: stats }),
  setIsLoadingStats: (isLoading) => set({ isLoadingStats: isLoading }),
  setError: (error) => set({ error }),
  addMediaItem: (media) => set((state) => ({
    mediaItems: [...state.mediaItems, media],
  })),
  removeMediaItem: (id) => set((state) => ({
    mediaItems: state.mediaItems.filter((item) => item.id !== id),
  })),
  updateMediaItem: (id, updates) => set((state) => ({
    mediaItems: state.mediaItems.map((item) =>
      item.id === id ? { ...item, ...updates } : item
    ),
  })),
  addTeamMember: (member) => set((state) => ({
    teamMembers: [...state.teamMembers, member],
  })),
  updateTeamMember: (id, updates) => set((state) => ({
    teamMembers: state.teamMembers.map((member) =>
      member.id === id ? { ...member, ...updates } : member
    ),
  })),
  removeTeamMember: (id) => set((state) => ({
    teamMembers: state.teamMembers.filter((member) => member.id !== id),
  })),
}));