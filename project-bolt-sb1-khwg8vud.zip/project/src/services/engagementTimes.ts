import { SocialPlatform } from '../types';

interface TimeSlot {
  time: string;
  score: number;
  engagement: number;
  description: string;
}

const formatTime = (time: string): string => time;

export const getOptimalEngagementTimes = (platform: SocialPlatform): TimeSlot[] => {
  const times: Record<SocialPlatform, TimeSlot[]> = {
    facebook: [
      { 
        time: formatTime('09:00'),
        score: 8.5,
        engagement: 85,
        description: 'Morning commute peak'
      },
      {
        time: formatTime('13:00'),
        score: 9.5,
        engagement: 95,
        description: 'Lunch break - highest engagement'
      },
      {
        time: formatTime('15:00'),
        score: 8.7,
        engagement: 87,
        description: 'Afternoon activity spike'
      },
      {
        time: formatTime('19:00'),
        score: 9.0,
        engagement: 90,
        description: 'Evening leisure time'
      },
      {
        time: formatTime('20:30'),
        score: 8.8,
        engagement: 88,
        description: 'Prime time engagement'
      }
    ],
    instagram: [
      {
        time: formatTime('11:00'),
        score: 9.2,
        engagement: 92,
        description: 'Late morning activity peak'
      },
      {
        time: formatTime('14:00'),
        score: 9.5,
        engagement: 95,
        description: 'Highest daily engagement'
      },
      {
        time: formatTime('15:00'),
        score: 9.0,
        engagement: 90,
        description: 'Afternoon browsing time'
      },
      {
        time: formatTime('18:00'),
        score: 8.8,
        engagement: 88,
        description: 'Post-work browsing'
      },
      {
        time: formatTime('21:00'),
        score: 9.3,
        engagement: 93,
        description: 'Evening entertainment hours'
      }
    ],
    twitter: [
      {
        time: formatTime('08:00'),
        score: 9.0,
        engagement: 90,
        description: 'Early morning news check'
      },
      {
        time: formatTime('12:00'),
        score: 9.4,
        engagement: 94,
        description: 'Lunch break conversations'
      },
      {
        time: formatTime('17:00'),
        score: 9.5,
        engagement: 95,
        description: 'Peak commute engagement'
      },
      {
        time: formatTime('18:00'),
        score: 9.2,
        engagement: 92,
        description: 'Evening news cycle'
      },
      {
        time: formatTime('21:00'),
        score: 8.8,
        engagement: 88,
        description: 'Late evening discussions'
      }
    ],
    linkedin: [
      {
        time: formatTime('08:00'),
        score: 9.3,
        engagement: 93,
        description: 'Early morning professional check-in'
      },
      {
        time: formatTime('10:30'),
        score: 9.5,
        engagement: 95,
        description: 'Mid-morning peak activity'
      },
      {
        time: formatTime('13:00'),
        score: 9.0,
        engagement: 90,
        description: 'Lunch break networking'
      },
      {
        time: formatTime('16:00'),
        score: 8.8,
        engagement: 88,
        description: 'Late workday engagement'
      },
      {
        time: formatTime('17:30'),
        score: 8.5,
        engagement: 85,
        description: 'End of workday wrap-up'
      }
    ],
    pinterest: [
      {
        time: formatTime('11:00'),
        score: 8.8,
        engagement: 88,
        description: 'Late morning inspiration'
      },
      {
        time: formatTime('15:00'),
        score: 9.0,
        engagement: 90,
        description: 'Afternoon DIY planning'
      },
      {
        time: formatTime('20:00'),
        score: 9.5,
        engagement: 95,
        description: 'Peak evening browsing'
      },
      {
        time: formatTime('21:00'),
        score: 9.3,
        engagement: 93,
        description: 'Evening planning time'
      },
      {
        time: formatTime('22:00'),
        score: 8.5,
        engagement: 85,
        description: 'Late night inspiration'
      }
    ],
    tiktok: [
      {
        time: formatTime('10:00'),
        score: 8.5,
        engagement: 85,
        description: 'Morning entertainment'
      },
      {
        time: formatTime('14:00'),
        score: 9.0,
        engagement: 90,
        description: 'Afternoon break viewing'
      },
      {
        time: formatTime('17:00'),
        score: 9.3,
        engagement: 93,
        description: 'After school/work peak'
      },
      {
        time: formatTime('19:00'),
        score: 9.5,
        engagement: 95,
        description: 'Prime time engagement'
      },
      {
        time: formatTime('22:00'),
        score: 9.2,
        engagement: 92,
        description: 'Late night entertainment'
      }
    ],
    youtube: [
      {
        time: formatTime('14:00'),
        score: 9.2,
        engagement: 92,
        description: 'Peak afternoon viewership'
      },
      {
        time: formatTime('16:00'),
        score: 9.0,
        engagement: 90,
        description: 'After school/work audience'
      },
      {
        time: formatTime('19:00'),
        score: 9.5,
        engagement: 95,
        description: 'Prime time viewing'
      },
      {
        time: formatTime('20:00'),
        score: 9.3,
        engagement: 93,
        description: 'Evening entertainment'
      },
      {
        time: formatTime('22:00'),
        score: 8.8,
        engagement: 88,
        description: 'Late night viewing'
      }
    ]
  };

  return times[platform] || [];
};