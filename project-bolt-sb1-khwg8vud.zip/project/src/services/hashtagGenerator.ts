import { debounce } from 'lodash';

// Simulated AI hashtag generation based on content analysis
const generateHashtagsFromContent = (content: string): string[] => {
  // This is a mock implementation. In production, this would call an AI service
  const words = content.toLowerCase().split(/\s+/).filter(word => word.length > 3);
  const industries = ['marketing', 'business', 'tech', 'startup', 'social', 'digital'];
  const actions = ['growth', 'tips', 'strategy', 'success', 'innovation'];
  const trending = ['socialmedia', 'contentcreator', 'influencer', 'entrepreneur'];
  
  const relevantHashtags = new Set<string>();
  
  // Generate relevant hashtags based on content
  words.forEach(word => {
    // Add direct word as hashtag if relevant
    if (word.length > 4) {
      relevantHashtags.add(word);
    }
    
    // Add industry-specific hashtags
    industries.forEach(industry => {
      if (word.includes(industry) || industry.includes(word)) {
        relevantHashtags.add(industry);
        relevantHashtags.add(`${industry}tips`);
      }
    });
    
    // Add action-based hashtags
    actions.forEach(action => {
      if (word.includes(action) || action.includes(word)) {
        relevantHashtags.add(action);
        relevantHashtags.add(`${action}mindset`);
      }
    });
  });
  
  // Add some trending hashtags
  trending.forEach(tag => {
    relevantHashtags.add(tag);
  });
  
  return Array.from(relevantHashtags).map(tag => `#${tag}`);
};

export const generateHashtags = debounce((content: string, callback: (hashtags: string[]) => void) => {
  if (content.length < 2) return;
  
  const hashtags = generateHashtagsFromContent(content);
  callback(hashtags);
}, 500);