export class APIError extends Error {
  constructor(
    message: string,
    public statusCode: number,
    public code: string
  ) {
    super(message);
    this.name = 'APIError';
  }
}

export function handleError(error: unknown): APIError {
  if (error instanceof APIError) {
    return error;
  }

  if (error instanceof Error) {
    return new APIError(
      error.message,
      500,
      'INTERNAL_SERVER_ERROR'
    );
  }

  return new APIError(
    'An unexpected error occurred',
    500,
    'INTERNAL_SERVER_ERROR'
  );
}

export function isNetworkError(error: unknown): boolean {
  return error instanceof Error && 
    (error.message.includes('network') || 
     error.message.includes('Network') ||
     error.message.includes('Failed to fetch'));
}

export function formatErrorMessage(error: unknown): string {
  const apiError = handleError(error);
  
  switch (apiError.code) {
    case 'RATE_LIMIT_EXCEEDED':
      return 'Too many requests. Please try again later.';
    case 'INVALID_CREDENTIALS':
      return 'Invalid credentials. Please reconnect your account.';
    case 'TOKEN_EXPIRED':
      return 'Your session has expired. Please log in again.';
    case 'NETWORK_ERROR':
      return 'Network error. Please check your connection.';
    default:
      return apiError.message;
  }
}