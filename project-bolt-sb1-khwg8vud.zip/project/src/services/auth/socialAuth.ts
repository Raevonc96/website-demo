import { SocialPlatform } from '../../types';

interface AuthConfig {
  clientId: string;
  redirectUri: string;
  scope: string[];
}

const configs: Record<SocialPlatform, AuthConfig> = {
  facebook: {
    clientId: import.meta.env.VITE_FACEBOOK_CLIENT_ID || '',
    redirectUri: `${window.location.origin}/auth/facebook/callback`,
    scope: ['pages_show_list', 'pages_read_engagement', 'pages_manage_posts'],
  },
  instagram: {
    clientId: import.meta.env.VITE_INSTAGRAM_CLIENT_ID || '',
    redirectUri: `${window.location.origin}/auth/instagram/callback`,
    scope: ['instagram_basic', 'instagram_content_publish'],
  },
  twitter: {
    clientId: import.meta.env.VITE_TWITTER_CLIENT_ID || '',
    redirectUri: `${window.location.origin}/auth/twitter/callback`,
    scope: ['tweet.read', 'tweet.write', 'users.read'],
  },
  linkedin: {
    clientId: import.meta.env.VITE_LINKEDIN_CLIENT_ID || '',
    redirectUri: `${window.location.origin}/auth/linkedin/callback`,
    scope: ['r_liteprofile', 'w_member_social'],
  },
  pinterest: {
    clientId: import.meta.env.VITE_PINTEREST_CLIENT_ID || '',
    redirectUri: `${window.location.origin}/auth/pinterest/callback`,
    scope: ['boards:read', 'pins:read', 'pins:write'],
  },
  tiktok: {
    clientId: import.meta.env.VITE_TIKTOK_CLIENT_ID || '',
    redirectUri: `${window.location.origin}/auth/tiktok/callback`,
    scope: ['user.info.basic', 'video.list', 'video.upload'],
  },
  youtube: {
    clientId: import.meta.env.VITE_YOUTUBE_CLIENT_ID || '',
    redirectUri: `${window.location.origin}/auth/youtube/callback`,
    scope: ['https://www.googleapis.com/auth/youtube.upload', 'https://www.googleapis.com/auth/youtube'],
  },
};

export const initiateAuth = (platform: SocialPlatform): void => {
  const config = configs[platform];
  
  // Check if client ID is configured
  if (!config.clientId) {
    throw new Error(`${platform} client ID not configured. Please set up your environment variables.`);
  }

  try {
    const state = generateState();
    const codeChallenge = generateCodeChallenge();
    
    const authUrls: Record<SocialPlatform, string> = {
      facebook: `https://www.facebook.com/v18.0/dialog/oauth?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&scope=${config.scope.join(',')}&response_type=code&state=${state}`,
      instagram: `https://api.instagram.com/oauth/authorize?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&scope=${config.scope.join(',')}&response_type=code&state=${state}`,
      twitter: `https://twitter.com/i/oauth2/authorize?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&scope=${config.scope.join(' ')}&response_type=code&code_challenge_method=S256&code_challenge=${codeChallenge}&state=${state}`,
      linkedin: `https://www.linkedin.com/oauth/v2/authorization?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&scope=${config.scope.join(' ')}&response_type=code&state=${state}`,
      pinterest: `https://www.pinterest.com/oauth/?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&scope=${config.scope.join(',')}&response_type=code&state=${state}`,
      tiktok: `https://www.tiktok.com/auth/authorize?client_key=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&scope=${config.scope.join(',')}&response_type=code&state=${state}`,
      youtube: `https://accounts.google.com/o/oauth2/v2/auth?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&scope=${config.scope.join(' ')}&response_type=code&access_type=offline&prompt=consent&state=${state}`,
    };

    // Store state for verification when the OAuth provider redirects back
    localStorage.setItem('oauth_state', state);
    localStorage.setItem('oauth_platform', platform);

    // Open OAuth window
    const width = 600;
    const height = 700;
    const left = window.screen.width / 2 - width / 2;
    const top = window.screen.height / 2 - height / 2;
    
    const authWindow = window.open(
      authUrls[platform],
      `Connect ${platform}`,
      `width=${width},height=${height},left=${left},top=${top}`
    );

    if (!authWindow) {
      throw new Error('Popup blocked. Please allow popups for this site.');
    }

  } catch (error) {
    console.error(`Error connecting to ${platform}:`, error);
    throw error;
  }
};

// Helper functions for OAuth security
function generateCodeChallenge(): string {
  const verifier = generateRandomString(128);
  localStorage.setItem('code_verifier', verifier);
  return btoa(verifier).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function generateState(): string {
  return generateRandomString(32);
}

function generateRandomString(length: number): string {
  const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let text = '';
  for (let i = 0; i < length; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}