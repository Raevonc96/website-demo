import { Post } from '../../types';

interface ContentScore {
  score: number;
  insights: string[];
  suggestions: string[];
}

export function analyzeContent(post: Partial<Post>): ContentScore {
  const score = {
    contentLength: calculateContentLengthScore(post.content || ''),
    hashtags: calculateHashtagScore(post.hashtags || []),
    media: calculateMediaScore(post.media || []),
    timing: calculateTimingScore(post.scheduledTime || ''),
  };

  const totalScore = Math.round(
    (score.contentLength + score.hashtags + score.media + score.timing) / 4 * 100
  );

  const insights = generateInsights(score);
  const suggestions = generateSuggestions(score);

  return {
    score: totalScore,
    insights,
    suggestions,
  };
}

function calculateContentLengthScore(content: string): number {
  const length = content.length;
  if (length === 0) return 0;
  if (length < 50) return 0.5;
  if (length < 100) return 0.7;
  if (length < 200) return 0.9;
  return 1.0;
}

function calculateHashtagScore(hashtags: string[]): number {
  const count = hashtags.length;
  if (count === 0) return 0.3;
  if (count < 3) return 0.6;
  if (count < 8) return 1.0;
  return 0.8; // Too many hashtags
}

function calculateMediaScore(media: any[]): number {
  if (media.length === 0) return 0.5;
  if (media.length === 1) return 0.8;
  return 1.0;
}

function calculateTimingScore(scheduledTime: string): number {
  if (!scheduledTime) return 0.5;
  
  const scheduledDate = new Date(scheduledTime);
  const hour = scheduledDate.getHours();
  
  // Peak engagement hours (9-11 AM, 1-3 PM, 7-9 PM)
  if ((hour >= 9 && hour <= 11) || 
      (hour >= 13 && hour <= 15) || 
      (hour >= 19 && hour <= 21)) {
    return 1.0;
  }
  
  // Moderate engagement hours (8-9 AM, 11 AM-1 PM, 3-7 PM)
  if ((hour >= 8 && hour < 9) || 
      (hour > 11 && hour < 13) || 
      (hour > 15 && hour < 19)) {
    return 0.8;
  }
  
  // Low engagement hours (before 8 AM, after 9 PM)
  return 0.6;
}

function generateInsights(scores: Record<string, number>): string[] {
  const insights: string[] = [];
  
  if (scores.contentLength < 0.7) {
    insights.push('Content length could be improved for better engagement');
  }
  
  if (scores.hashtags < 0.6) {
    insights.push('Adding relevant hashtags can increase visibility');
  }
  
  if (scores.media < 0.8) {
    insights.push('Posts with media typically perform better');
  }
  
  if (scores.timing < 0.8) {
    insights.push('Consider posting during peak engagement hours');
  }
  
  return insights;
}

function generateSuggestions(scores: Record<string, number>): string[] {
  const suggestions: string[] = [];
  
  if (scores.contentLength < 0.7) {
    suggestions.push('Add more context or details to your post (aim for 100-200 characters)');
  }
  
  if (scores.hashtags < 0.6) {
    suggestions.push('Include 3-5 relevant hashtags for optimal reach');
  }
  
  if (scores.media < 0.8) {
    suggestions.push('Add an image or video to increase engagement');
  }
  
  if (scores.timing < 0.8) {
    suggestions.push('Schedule your post during peak hours (9-11 AM, 1-3 PM, or 7-9 PM)');
  }
  
  return suggestions;
}